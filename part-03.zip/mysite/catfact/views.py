from django.shortcuts import render
from django.http import HttpResponse
import requests
from catfact.models import catjoke

def random(request):
    req = requests.get('https://cat-fact.herokuapp.com/facts/random?animal_type=cat')
    facts = req.json()
    text = facts['text']
    model_joke = catjoke(joke = text)
    model_joke.save()
    return HttpResponse('<p>{}</p>'.format(text))

def viewall(request):
    html = '<p>'
    facts = catjoke.objects.order_by('-id')[:5]
    for joke in facts:
        html += str(joke)
        html += '<br>'
    html += '</p>'
    return HttpResponse(html)
