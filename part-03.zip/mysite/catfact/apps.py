from django.apps import AppConfig


class CatfactConfig(AppConfig):
    name = 'catfact'
