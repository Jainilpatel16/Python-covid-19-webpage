from django.apps import AppConfig


class Covid19Config(AppConfig):
    name = 'covid19'
